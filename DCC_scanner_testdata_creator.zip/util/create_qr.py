import json
from pathlib import Path

import qrcode


def make_qr(data):
    contents = json.dumps(data)
    qr = qrcode.QRCode(version=1, box_size = 15, border = 5)
    qr.add_data(contents)
    qr.make(fit=True)

    return qr


def make_image(qr, img_name):
    output_path = Path.cwd() / "output"
    if not output_path.exists():
        output_path.mkdir()

    qr_path = output_path / "qr_codes"
    if not qr_path.exists():
        qr_path.mkdir()

    img = qr.make_image(fill="black", back_color="white")
    img_path = str(qr_path / f"{img_name}.png")
    img.save(img_path)


def create_qr(qr_data, test_name):
    qr = make_qr(qr_data)
    make_image(qr, test_name)
