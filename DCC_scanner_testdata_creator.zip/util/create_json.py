import json

from pathlib import Path

json_path = Path.cwd() / "output" / "jsons"


def create_json(qr_data, test_name):
    if not json_path.exists():
        json_path.mkdir()

    json_file_path = json_path / f"{test_name}.json"
    with open(json_file_path, 'w') as outputfile:
        json.dump(qr_data, outputfile)
