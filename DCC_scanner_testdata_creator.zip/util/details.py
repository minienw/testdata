import json

from collections.abc import MutableMapping
from pathlib import Path

inputpath = Path.cwd() / 'input'

with open(inputpath / 'default.json') as defaultfile:
    default = json.load(defaultfile)["Default"]

with open(inputpath / 'valuesets.json') as valuesetsfile:
    valuesets = json.load(valuesetsfile)

class Details(MutableMapping):
    def __init__(self, detail_type, *args, **kwargs):
        self.store = dict()
        self.update(dict(*args, **kwargs))
        self.default = default[detail_type]

    def __getitem__(self, key):
        result = self.store[key] if key in self.store else self.default[key]
        if key in valuesets and result in valuesets[key]:
            result = valuesets[key][result]
        return result

    def __setitem__(self, key, value):
        self.store[key] = value

    def __delitem__(self, key):
        del self.store[key]

    def __iter__(self):
        return iter(self.store)
    
    def __len__(self):
        return len(self.store)


def get_details(event, detail_type):
    event_details = event.get(detail_type, {})
    details = Details(detail_type, event_details)
    return details

