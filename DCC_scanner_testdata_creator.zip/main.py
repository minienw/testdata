import json

from datetime import datetime, timedelta
from pathlib import Path

from util import create_json, create_qr
from util.details import get_details


def add_general_data(qr_data, test_data):
    details = get_details(test_data, "General")

    qr_data["credentialVersion"] = details["Credential version"]
    qr_data["issuer"] = details["Issuer"]
    qr_data["issuedAt"] = details["Issued at"]
    qr_data["expirationTime"] = details["Expiration time"]

    if "dcc" not in qr_data:
        qr_data["dcc"] = {}


def add_dcc_data(qr_data, test_data):
    details = get_details(test_data, "DCC")
    dcc_version = details["DCC version"]

    name = {}
    name["fn"] = details["Last name"]
    name["fnt"] = details.get("Last name T", name["fn"].upper())
    name["gn"] = details["First name"]
    name["gnt"] = details.get("First name T", name["gn"].upper())

    dcc = qr_data["dcc"]
    dcc["ver"] = dcc_version
    dcc["nam"] = name
    dcc["dob"] = details["Date of birth"]


def add_recovery_data(qr_data, details):
    if "r" not in qr_data["dcc"]:
        qr_data["dcc"]["r"] = []

    date_now = datetime.now()
    positive_test_age = details["First positive test age"]
    positive_test_diff = timedelta(days=positive_test_age)
    positive_test_date = (date_now - positive_test_diff).strftime("%Y-%m-%d")

    valid_from_age = details["Valid from"]
    valid_from_diff = timedelta(days=valid_from_age)
    valid_from_date = (date_now - valid_from_diff).strftime("%Y-%m-%d")

    valid_to_age = details["Valid to"]
    valid_to_diff = timedelta(days=valid_to_age)
    valid_to_date = (date_now + valid_to_diff).strftime("%Y-%m-%d")

    recovery_data = {
        "tg": details["Disease targeted"],
        "fr": positive_test_date,
        "co": details["Country"],
        "is": details["Institute"],
        "df": valid_from_date,
        "du": valid_to_date,
        "ci": details["Certificate"]
    }

    qr_data["dcc"]["r"].append(recovery_data)


def add_test_data(qr_data, details):
    if "t" not in qr_data["dcc"]:
        qr_data["dcc"]["t"] = []

    test_age = details["Test age"]
    time_now = datetime.now()
    time_diff = timedelta(hours=test_age+2)

    test_time = (time_now - time_diff).strftime("%Y-%m-%dT%H:%M:%SZ")

    test_data = {
        "tg": details["Disease targeted"],
        "tt": details["Test type"],
        "tr": details["Test result"],
        "nm": details["Test name"],
        "ma": details["Test manufacturer"],
        "tc": details["DCC supplier"],
        "co": details["Country"],
        "is": details["Institute"],
        "ci": details["Certificate"],
        "sc": test_time
    }

    qr_data["dcc"]["t"].append(test_data)


def add_vaccination_data(qr_data, details):
    if "v" not in qr_data["dcc"]:
        qr_data["dcc"]["v"] = []

    vaccin_age = details["Vaccine age"]
    date_now = datetime.now()
    vaccin_diff = timedelta(days=vaccin_age)

    vaccin_date = (date_now - vaccin_diff).strftime("%Y-%m-%d")

    test_data = {
        "tg": details["Disease targeted"],
        "vp": details["Vaccine"],
        "mp": details["Vaccine Medical Product"],
        "ma": details["Vaccine manufacturer"],
        "dn": details["Dose number"],
        "sd": details["Total series of doses"],
        "dt": vaccin_date,
        "co": details["Country"],
        "is": details["Institute"],
        "ci": details["Certificate"]
    }

    qr_data["dcc"]["v"].append(test_data)


def add_event_data(qr_data, event):
    event_type = event["Event type"]
    details = get_details(event, event_type)
    if event_type == "Test":
        add_test_data(qr_data, details)
    elif event_type == "Recovery":
        add_recovery_data(qr_data, details)
    elif event_type == "Vaccination":
        add_vaccination_data(qr_data, details)
    else:
        raise ValueError(f"Event Type '{event_type}' is invalid!")


def data_to_qr(test_data):
    name = test_data["Name"]
    test_name = name.lower().replace(" ", "_")

    qr_data = {}

    add_general_data(qr_data, test_data)
    add_dcc_data(qr_data, test_data)

    events = test_data.get("Events", [])
    for event in events:
        add_event_data(qr_data, event)

    create_qr.create_qr(qr_data, test_name)
    create_json.create_json(qr_data, test_name)


if __name__ == "__main__":
    testcases_path = Path.cwd() / "input" / "testcases.json"
    with open(testcases_path) as inputfile:
        inputdata = json.load(inputfile)

        for testcase in inputdata["Testcases"]:
            data_to_qr(testcase)
